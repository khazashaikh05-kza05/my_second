// js/script.js
// Small, fast JS for navigation toggle, hadith search, and contact form.
// Keeps everything client-side for fast loading.

document.addEventListener('DOMContentLoaded', function () {
  // Responsive nav toggle
  const toggles = document.querySelectorAll('.menu-toggle');
  toggles.forEach(btn => {
    btn.addEventListener('click', () => {
      const nav = document.getElementById('mainNav');
      if (!nav) return;
      nav.style.display = (nav.style.display === 'flex' ? 'none' : 'flex');
      nav.style.flexDirection = 'column';
    });
  });

  // Hadith search and filter (if present)
  const searchInput = document.getElementById('hadithSearch');
  const filterSelect = document.getElementById('hadithFilter');
  const hadithList = document.getElementById('hadithList');

  function normalizeText(s) {
    return (s || '').toLowerCase();
  }

  if (searchInput && hadithList) {
    const items = Array.from(hadithList.querySelectorAll('.hadith-item'));
    function runFilter() {
      const q = normalizeText(searchInput.value);
      const f = filterSelect ? filterSelect.value : 'all';
      items.forEach(item => {
        const cat = item.getAttribute('data-category') || 'all';
        const text = normalizeText(item.textContent);
        const matchesQuery = q === '' || text.indexOf(q) !== -1;
        const matchesFilter = f === 'all' || f === cat;
        item.style.display = (matchesQuery && matchesFilter) ? '' : 'none';
      });
    }
    searchInput.addEventListener('input', runFilter);
    if (filterSelect) filterSelect.addEventListener('change', runFilter);
  }

});

// Simple contact form handler (client-side demo)
function contactSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  const status = document.getElementById('contactStatus');
  if (!name || !email || !message) {
    status.textContent = 'దయచేసి అన్ని ఫీల్డ్స్ భర్తీ చేయండి.';
    return false;
  }
  // Simulate success (no backend). In production, POST to server.
  status.textContent = 'మీ సందేశం పంపబడింది. ధన్యవాదాలు!';
  // Clear fields
  document.getElementById('name').value = '';
  document.getElementById('email').value = '';
  document.getElementById('message').value = '';
  return false;
}